A python implementation of the Pluggable Transports for Circumvention specification for Tor


